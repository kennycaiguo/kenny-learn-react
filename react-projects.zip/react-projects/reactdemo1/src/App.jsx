import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'
let person = {
    name:'Jennifer',
    gender:'female',
    age:19,
    email:'Jennifer1234.goodies@gmail.com'
}
let hello = (
    <div>
       <h3>About {person.name}</h3>
        <p>Name:{person.name}</p>
        <p>Gender:{person.gender}</p>
        <p>Age:{person.age}</p>
        <p>Email:{person.email}</p>
    </div>
)

function App() {
  const [count, setCount] = useState(0)

  return (
    <>

      <h2>Personal info</h2>
      <div>
          {hello}
      </div>

    </>
  )
}

export default App
