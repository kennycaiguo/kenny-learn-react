import axios from "axios";

//创建一个请求对象
let request = axios.create({
   baseURL:"http://localhost:3000",
   timeout:5000
})

//配置响应拦截器
request.interceptors.response.use(res => res.data)

export default request
