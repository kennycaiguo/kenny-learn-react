import {Navigate, Route, Routes, useLocation, useNavigate} from "react-router-dom";
import UsersPage from "../pages/index/users/UsersPage.jsx";
import RolesPage from "../pages/index/roles/RolesPage.jsx";
import ProductsCategory from "../pages/index/products/ProductsCategory.jsx";
import ProductsList from "../pages/index/products/ProductsList.jsx";
import FinancesSale from "../pages/index/finances/FinancesSale.jsx";
import {lazy, useMemo, useState} from "react";
import { Modal } from 'antd'
import IndexPage from "../pages/index/IndexPage.jsx";
import HomePage from "../pages/index/home/HomePage.jsx";
import ProductsUpdateDynamic from "../pages/index/products/ProductsUpdateDynamic.jsx";
import ProductsUpdate from "../pages/index/products/ProductsUpdate.jsx";
import LoginPage from "../pages/login/LoginPage.jsx";
const NotFound =  lazy(()=>import("../pages/404/NotFound.jsx")) ;

let routes = [
    {path:"home" ,element :<HomePage/>,authPath:'/home'},
    {path:"users" ,element :<UsersPage/>,authPath:'/home/user'},
    {path:"roles" ,element :<RolesPage/>,authPath:'/home/role'},
    {path:"products/category" ,element :<ProductsCategory/>,authPath:'/home/product/category'},
    {path:"products/list" ,element :<ProductsList/>,authPath:'/home/product/list'},
    {path:"finances/sale" ,element :<FinancesSale/>,authPath:'/home/datav/sale'},
]

const AddRoute = () => {
    const [authRoutes,setAuthRoutes] = useState([])
    const navigate = useNavigate()
    let { pathname } = useLocation()
    console.log("当前路径",pathname)
    //1.判断为登录用户访问的利用是否是当前下面在存在的路由
    const isRoute = routes.some(item=>"/"+ item.path === pathname)
    // console.log(isRoute)
    // 如果用户访问的路由是我们项目的路由，isRoute就是true
    if(isRoute){
        //2.如果用户访问的是我们项目的路由，需要判断他是否已经登录
        let userInfo = localStorage.userInfo
        //2.1进入if，表明用户已经登录
        if(userInfo){
            //2.2获取用户能够访问的权限路径
            if(authRoutes.length == 0){
                let {role:{menus}} = JSON.parse(userInfo)
                setAuthRoutes(routes.filter(item=>menus.includes(item.authPath)))
                // console.log("authRoutes:",authRoutes)
             }
        } else { //3.进入这里说明用户没有登录，引导他去登录
            Modal.warning({
                title:'未登录提示',
                content:'你还未登录，请先登录',
                afterClose:()=>{
                  navigate('/login')
                }
            })
        }
    }
  // 动态生成404路由，需要用到计算属性
  let isNotFound = useMemo(()=>{
    //对于任何用户来说，访问项目中不存在的路径就返回404
    //对应登录的用户，如果你没有权限访问指定的路径，也返回404
      return !isRoute || (localStorage.token && isRoute && !authRoutes.find(item=>pathname == '/'+item.path))
  },[isRoute])
    // console.log(isNotFound)

    return (
        <Routes>
            <Route path="/" element ={<Navigate to="/home"/>}></Route>
            <Route path="login" element={<LoginPage/>}></Route>
          <Route path="/" element={<IndexPage/>}>
              {
                  authRoutes.map(item=>(
                          <Route key={item.path} path={item.path} element = {item.element} ></Route>
                  ))
              }

        </Route>
            {/*根据条件是否为true来显示或者不显示404页面*/}
            {isNotFound ? <Route path='*' element={<NotFound/>}></Route> : null}
      </Routes>
    );
};

export default AddRoute;