import React, {useEffect, useMemo, useState} from 'react';
import {useDispatch, useSelector} from "react-redux";
import {getCategoryAsync, setSubCategoryAction} from "../../../store/category/actions";
import { Space,Tag, Switch, Table } from 'antd';
import {getCategoryApi} from "../../../api/category";
import {Link} from "react-router-dom";


const columns = [
    {
        title: '分类名称',
        dataIndex: 'name',
    },
    {
        title: '类别',
        dataIndex: 'type',
        render:(text)=>{
            if(text=="一级分类"){
                return <Tag color="magenta">{text}</Tag>
            }else if(text=="二级分类"){
                return <Tag color="blue">{text}</Tag>
            }
            return  text
        }
    },
    {
        title: '操作',
        dataIndex: 'action',
        render:(_,record) =>(
                <Space>
                   {/* 方式一 动态路由*/}
                   {/*<Link to={"/products/update/"+ record.id}>修改</Link>*/}
                   {/* 方式2 state传参*/}
                   {/*<Link to="/products/update" state ={{id:record.id}}>修改</Link>*/}
                   <Link to="" state ={{id:record.id}}>修改</Link>
                   <a>删除</a>
                </Space>
            )


    },
];


const ProductsCategory = () => {

    //先从仓库里面获取数据，看看是否是空数组
    let categoryData = useSelector((state)=>{
        return state.category
    })
    console.log("categoryData:",categoryData)

    //显示+号的方式1，用计算属性来给数据添加children属性
    // let category = useMemo(()=>{
    //
    //     return categoryData.map(item=>{
    //         //如果没有children就给他添加一个空数组作为children
    //         if(!item.children){
    //             return {
    //                 ...item ,//保留旧属性
    //                 children : [] //有了这个属性，表格才有+号
    //             }
    //         }
    //         //如果有children就直接返回
    //         return item
    //     })
    // },[categoryData])

    //显示+号的方式2 不使用计算属性，需要修改reducers.js的代码，可以在reducers.js中修改代码

    useEffect(()=>{
        getCategory()
    },[])
    //接收一个dispatch函数，用来调用仓库的公共方法
    let dispatch = useDispatch()

    //发送异步请求获取数据
    let getCategory = ()=>{
        //调用自己封装的仓库方法,不能直接调用，需要使用dispatch方法来调用
        dispatch(getCategoryAsync({parentId:0}))

    }
     //点击表格列上面的+号的事件处理
    let  onExpand = async (expanded,record) => {
        console.log(expanded,record)
        //需要根据expanded来判断是否需要发送请求获取二级数据
        if(expanded){
            //获取数据,这里不能使用仓库的方法，因为它是用来获取一级分类数据的
            //这里需要直接调用api
            let res = await getCategoryApi({parentId:record.id})
            if(res){
                console.log(res)
                //用请求结果修改仓库数据，还是需要使用dispatch方法
                // dispatch({type:'SET_SUB_CATEGORY',payload:{parentId:record.id,children:res}})
                dispatch(setSubCategoryAction({parentId:record.id,children:res}))

            }

        }
    }

    return (
        <>
            <Table columns={columns} dataSource={categoryData} rowKey="id" expandable={{ onExpand }}/>
        </>
    );
};

export default ProductsCategory;