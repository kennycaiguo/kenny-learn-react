import {useEffect} from 'react';
import {useLocation} from "react-router-dom";
import {findProductByIdApi} from "../../../api/products";

const ProductsUpdate = () => {
    //state传参方式接收参数
    let location = useLocation()
    console.log(location)

    useEffect(()=>{
        //state传参的调用方式
        getProductById(location.state.id)
    },[])

    let getProductById = async (id)=>{
        let data = await findProductByIdApi(id)
        console.log(data)
    }

    return (
        <div>
            update 页面
        </div>
    );
};

export default ProductsUpdate;

