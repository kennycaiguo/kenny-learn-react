import  {useEffect} from 'react';
import { useParams} from "react-router-dom";
import {findProductByIdApi} from "../../../api/products";
import useCascader from "../../../hooks/useCascader";

const ProductsUpdate = () => {
    //动态路由方式的接收参数
    let params = useParams();
    console.log(params)

    useEffect(()=>{
        //动态路由的调用方式
        getProductById(params.id)
    },[])

    let getProductById = async (id)=>{
        let data = await findProductByIdApi(id)
        console.log(data)
    }

    let {cascaderData} = useCascader()
    console.log("cascaderData:",cascaderData)

    return (
        <div>
            update 页面
        </div>
    );
};

export default ProductsUpdate;