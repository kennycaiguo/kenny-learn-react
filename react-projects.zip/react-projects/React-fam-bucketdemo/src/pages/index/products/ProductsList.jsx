import React, {useEffect, useState} from 'react';
import { Divider, Radio, Table,Space } from 'antd';
import {getProductsApi} from "../../../api/products";
import {Link} from "react-router-dom";

const columns = [
    {
        title: '商品名称',
        dataIndex: 'name',
        render: (text) => <a>{text}</a>,
    },
    {
        title: '描述',
        dataIndex: 'title',
    },
    {
        title: '价格',
        dataIndex: 'price',
    },
    {
        title: '类别',
        dataIndex: ['type','name'],
    },
    {
        title: '操作',
        dataIndex: 'action',
        render:(_,record)=>{
            return (
                <Space>
                    {/*方式1 动态路由传参*/}
                    <Link to={"/products/update/"+record.id}>修改</Link>
                    {/*方式2 state传参，还是需要Link*/}
                    <Link to="/products/update" state={{id:record.id}}>修改</Link>
                    <a>删除</a>
                </Space>
            )
        }
    },
];

// rowSelection object indicates the need for row selection
const rowSelection = {
    onChange: (selectedRowKeys, selectedRows) => {
        console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
    }
};

const ProductsList = () => {
    //状态
     let [productsData,setProductsData] = useState([])
    //方法
    let getProducts = async ()=>{
        let data = await getProductsApi()
        // console.log(data)
        setProductsData([...data])
        console.log("products:",productsData)
    }

     useEffect(()=>{
       getProducts()

     },[])
    return (
        <div>
            <Table
                rowSelection={{type: 'checkbox', ...rowSelection}}
                columns={columns}
                dataSource={productsData}
                rowKey={"id"}
            />
        </div>
    );
};

export default ProductsList;