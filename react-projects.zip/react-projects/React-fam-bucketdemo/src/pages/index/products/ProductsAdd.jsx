import React from 'react';
import useCascader from "../../../hooks/useCascader";

const ProductsAdd = () => {
    let {cascaderData} = useCascader()
    return (
        <div>
            
        </div>
    );
};

export default ProductsAdd;