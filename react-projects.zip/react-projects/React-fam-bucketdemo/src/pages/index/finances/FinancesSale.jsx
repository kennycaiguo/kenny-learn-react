import {useEffect} from 'react';
import {useSelector,useDispatch} from "react-redux";
import {getUsersAsync} from "../../../store/users/actions";


const FinancesSale = () => {
    let dispatch = useDispatch()
    useSelector(state => { //如果需要在页面渲染数据，需要用一个变量把这个hook的返回值接收，然后再再适当的地方渲染
        console.log(state)
       return state.users
    })
    //定义组件自己的方法
    let getUsers = () =>{
        dispatch(getUsersAsync())
    }

    useEffect(()=>{
        getUsers()
    },[])
    return (
        <div>
            销售金额
        {/*    在这里渲染数据*/}
        </div>
    );
};

export default FinancesSale;