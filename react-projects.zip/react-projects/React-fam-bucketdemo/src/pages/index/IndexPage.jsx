import { Layout, Menu, theme } from 'antd';
import './index.css'
import SideMenu from "../../components/side-menu/SideMenu";
import {Outlet} from 'react-router-dom'
import IndexBreadcrumb from "../../components/index-breadcrumb/IndexBreadcrumb";

const { Header, Content, Sider } = Layout;
const items1 = ['1', '2', '3'].map((key) => ({
    key,
    label: `nav ${key}`,
}));

const IndexPage = () => {
    const {
        token: { colorBgContainer, borderRadiusLG },
    } = theme.useToken();
    return (
        <Layout id="index-layout">
            <Header
                style={{
                    display: 'flex',
                    alignItems: 'center',
                }}
            >
                <div className="logo" />
                <Menu
                    theme="dark"
                    mode="horizontal"
                    defaultSelectedKeys={['2']}
                    items={items1}
                    style={{
                        flex: 1,
                        minWidth: 0,
                    }}
                />
            </Header>
            <Layout>
                <Sider  className="site-layout-background" width={200} >
                    <SideMenu></SideMenu>
                </Sider>
                <Layout
                    style={{
                        padding: '0 24px 24px',
                    }}
                >
                    {/*使用自己封装的面包屑*/}
                    <IndexBreadcrumb></IndexBreadcrumb>
                    <Content className="site-layout-background index-content" >

                        {/*在这里配置二级路由出口*/}
                     <Outlet/>
                    </Content>
                </Layout>
            </Layout>
        </Layout>
    );
};

export default IndexPage;