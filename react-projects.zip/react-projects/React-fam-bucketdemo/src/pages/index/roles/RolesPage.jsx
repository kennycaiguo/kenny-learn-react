import React, {useEffect} from 'react';
import {useDispatch, useSelector} from "react-redux";
import {getRolesAsync} from "../../../store/roles/actions";

const RolesPage = () => {
    //接收一个dispatch函数，用来调用仓库的公共方法
    let dispatch = useDispatch();
    //从仓库里面获取数据
    let rolesData = useSelector((state)=>{
        return state.roles
    })
    console.log("rolesData",rolesData)
    let getRoles = ()=>{
        //调用仓库公共方法
        dispatch(getRolesAsync())
    }

    useEffect(()=>{
        getRoles()
    },[])
    return (
        <div>
            role page
        </div>
    );
};

export default RolesPage;