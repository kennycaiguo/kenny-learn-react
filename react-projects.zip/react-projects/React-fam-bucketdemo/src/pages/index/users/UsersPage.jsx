import React, {useEffect, useState} from 'react';
import {addUserApi, delUserApi, getUserApi, updateUserApi} from "../../../api/users";
import {getRolesApi} from "../../../api/roles";
//引入表格组件
import { Space, Table, Tag, Modal,Select } from 'antd';
import { Button, Divider, Popconfirm,Form,Input } from 'antd';


const UsersPage = () => {
    //状态数据
    //保存所有用户状态数据
    let [usersData,setUsersData] = useState([])
    //保存所有角色状态数据
    let [rolesData,setRolesData] = useState([])
    //保存需要新增的数据的状态
    let [addData,setAddData] = useState({})
    //保存需要修改的数据的状态
    let [updateData,setUpdateData] = useState({})
    //控制新增用户的弹窗显示隐藏的状态
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    //控制修改用户的弹窗状显示隐藏态数据
    const [isUpdateModalOpen, setIsUpdateModalOpen] = useState(false);
    //更新表单数据需要的
    const [form] = Form.useForm()

    const showAddModal = () => {
        setIsAddModalOpen(true);
    };
    const addUsers = async () => {

        //发送post请求新增数据
        let res = await addUserApi(addData)
        console.log("result:",res)
        setIsAddModalOpen(false);
        getUsers()
    };
    const handleAddCancel = () => {
        setIsAddModalOpen(false);
    };
    const showUpdateModal = () => {
        setIsUpdateModalOpen(true);
    };
    //获取弹窗数据，打开弹窗，修改数据
    let getUpdateUser = (updateData) =>{
        setUpdateData(updateData)//虽然改变了数据，但是表单不会更新
        //更新表单默认值
        form.setFieldsValue({//注意：这里不能直接私有...了扩展updateData
            id:updateData.id,
            account:updateData.account,
            password:updateData.password,
            email:updateData.email,
            role:updateData.role.id
        })
        setIsUpdateModalOpen(true)
    }
    //修改用户数据功能
    let updateUsers = () =>{
        console.log("data ready:",updateData)
        updateUserApi(updateData.id,updateData)
        getUsers()
        setIsUpdateModalOpen(false)
    }
    let handleUpdateCancel = () =>{
        setIsUpdateModalOpen(false)
    }
    //收集表单数据并且设置到需要保存的数据状态中
    let onAddChange = (changedValues,allValues) =>{
        // console.log("rolesdata:",rolesData)
        if(allValues.role){
            let id = allValues.role
            let obj = rolesData.filter(item=>item.id == id)[0]
            // console.log("filter result:",obj)
            let roleObj = {
                id:id,
                name:obj.name
            }
            allValues.role =roleObj
        }
        console.log(allValues)
        setAddData(allValues)
    }

   //用户修改表单数据时触发这个函数
    let onUpdateChange = (changedValues,allValues) =>{
        if(allValues.role){
            let id = allValues.role
            let obj = rolesData.filter(item=>item.id == id)[0]
            // console.log("filter result:",obj)
            let roleObj = {
                id:id,
                name:obj.name
            }
            allValues.role =roleObj
        }
        console.log(allValues)
        setUpdateData(allValues)
    }

    useEffect(()=>{
        getUsers()
        getRoles()
    },[])


    //获取所有用户
    let getUsers = async () =>{
        let res = await getUserApi()
        //如果你请求的是真正的后端，需要用res.code来判断是否请求成功，1是成功，0是失败
        if(res){
            console.log(res)
            setUsersData([...res]) //这个res不是数组，只是一个类数组对象，需要利用扩展操作符给数组赋值
        }

    }
    //获取所有角色
    let getRoles = async () =>{
        let roles = await getRolesApi()
        console.log(roles)
        setRolesData([...roles])
    }
    //删除用户
    let delUser = async (id) =>{
        let res = delUserApi(id)
        console.log(res)
        await getUsers()

    }
    // const roleChange = (value) => {
    //     console.log(`selected ${value}`);
    // };


    const columns = [
        {
            title: '账号',
            dataIndex: 'account',
            render: (text) => <a>{text}</a>,
        },
        {
            title: '邮箱',
            dataIndex: 'email',
        },
        {
            title: '角色',
            dataIndex: ['role','name'],
            render:(text)=>text==="超级管理员" ? <Tag color="volcano">{text}</Tag> : <span>{text}</span>
        },

        {
            title: '操作',
            key: 'action',
            render: (_, record) => {
                return  (
                    <Space size="middle">
                        <a onClick={()=>getUpdateUser(record)}>修改</a>
                        <Popconfirm
                            title="删除确认"
                            description="删除不可恢复，你确定删除吗?"
                            onConfirm={()=>delUser(record.id)}
                            cancelText="取消"
                            okText="确认"
                        >
                            <a>删除</a>
                        </Popconfirm>

                    </Space>
                )
            }
            ,
        },
    ];



    return (
        <>
            {/*新增用户弹窗*/}
            <Modal title="新增用户" open={isAddModalOpen} onOk={addUsers} onCancel={handleAddCancel}>
                <Form labelCol={{span: 4,}} wrapperCol={{span: 18,}} style={{maxWidth: 600,}} onValuesChange={onAddChange}>
                    <Form.Item
                        label="用户id"
                        name="id"
                        rules={[
                            {
                                required: true,
                                message: '请输入用户id!',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="账号"
                        name="account"
                        rules={[
                            {
                                required: true,
                                message: '请输入账号',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="密码"
                        name="password"
                        rules={[
                            {
                                required: true,
                                message: '请输入密码!',
                            },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item
                        label="邮箱"
                        name="email"
                        rules={[
                            {
                                required: true,
                                message: '请输入邮箱!',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="角色"
                        name="role"
                        rules={[
                            {
                                required: true,
                                message: '请选择角色!',
                            },
                        ]}
                    >
                        <Select fieldNames={{label:'name',value:'id'}}
                            options={rolesData}
                        />
                    </Form.Item>

                </Form>
            </Modal>
            {/*修改用户弹窗*/}
            <Modal title="修改用户" open={isUpdateModalOpen} onOk={updateUsers} onCancel={handleUpdateCancel}>
                <Form form={form} labelCol={{span: 4,}} wrapperCol={{span: 18,}} style={{maxWidth: 600,}}
                      onValuesChange={onUpdateChange} initialValues={updateData}>
                    <Form.Item
                        label="用户id"
                        name="id"
                        rules={[
                            {
                                required: true,
                                message: '请输入用户id!',
                            },
                        ]}
                    >
                        <Input   disabled="disabled" />
                    </Form.Item>
                    <Form.Item
                        label="账号"
                        name="account"
                        rules={[
                            {
                                required: true,
                                message: '请输入账号',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="密码"
                        name="password"
                        rules={[
                            {
                                required: true,
                                message: '请输入密码!',
                            },
                        ]}
                    >
                        <Input.Password />
                    </Form.Item>
                    <Form.Item
                        label="邮箱"
                        name="email"
                        rules={[
                            {
                                required: true,
                                message: '请输入邮箱!',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>
                    <Form.Item
                        label="角色"
                        name="role"
                        rules={[
                            {
                                required: true,
                                message: '请选择角色!',
                            },
                        ]}
                    >
                        <Select fieldNames={{label:'name',value:'id'}}
                            options={rolesData}
                        />
                    </Form.Item>

                </Form>
            </Modal>
            <Button type="primary" onClick={showAddModal}>新增</Button>
            <Divider/>
            <Table columns={columns} dataSource={usersData} rowKey="id"/>;
        </>
    );
};

export default UsersPage;