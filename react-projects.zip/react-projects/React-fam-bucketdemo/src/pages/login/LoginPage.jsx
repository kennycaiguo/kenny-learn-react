// eslint-disable-next-line no-unused-vars
import React from 'react';
// eslint-disable-next-line no-unused-vars
import {Button,Card,Space} from "antd";
import { Form, Input } from 'antd';

import {Link,useNavigate} from 'react-router-dom'
import {loginApi} from "../../api/main.js";


const LoginPage = () => {
   let navigate = useNavigate();
    const onFinish = async (values) => {

        // console.log('Success:', values);
        let res = await loginApi(values)
        // console.log("登录结果：",res)
        if(res){
            //登录成功后需要把token和userInfo保存到localStorage中
            // console.log(res.token)
            localStorage.token = res.token
            // console.log(res.userInfo)
            localStorage.userInfo = JSON.stringify(res.userInfo)
            //登录成功后需要跳转到首页
            navigate('/home',{replace:true})
        }
    };

    return (
        <div>
            <Card
                title="用户登录"
                extra={<Link to="/register">去注册</Link>}
                style={{
                    width: 500,margin:'100px auto'
                }}
            >
                <Form
                    name="basic"
                    labelCol={{
                        span: 4,
                    }}
                    wrapperCol={{
                        span: 18,
                    }}
                    style={{
                        maxWidth: 600,
                    }}

                    onFinish={onFinish}
                >
                    <Form.Item
                        label="账号"
                        name="account"
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item
                        label="密码"
                        name="password"
                    >
                        <Input.Password />
                    </Form.Item>

                    <Form.Item
                        name="remember"
                        valuePropName="checked"
                        wrapperCol={{
                            offset: 8,
                            span: 16,
                        }}
                    >
                    </Form.Item>

                    <Form.Item
                        wrapperCol={{
                            offset: 8,
                            span: 16,
                        }}
                    >
                        <Button type="primary" htmlType="submit">
                            登录
                        </Button>
                    </Form.Item>
                </Form>
            </Card>

        </div>
    );
};

export default LoginPage;