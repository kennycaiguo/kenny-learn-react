import {useEffect, useState} from "react";
import {getCascaderCategoryApi} from "../api/category";

let useCascader = ()=>{
    let [cascaderData,setCascaderData] = useState([])
    useEffect(()=>{
       getCascaderCategory()
    },[])

    let getCascaderCategory = async () =>{
         let res = await getCascaderCategoryApi()
        // console.log("获取数据：",res)
         if(res){
            setCascaderData(res)
         }

    }
    return {cascaderData}
}

export default useCascader