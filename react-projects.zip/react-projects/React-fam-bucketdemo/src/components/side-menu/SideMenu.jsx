import {Menu} from "antd";
import {HomeOutlined,UserOutlined,TeamOutlined,
    BarcodeOutlined,BarsOutlined,BarChartOutlined,
    PayCircleOutlined,MoneyCollectOutlined,ShoppingCartOutlined} from "@ant-design/icons";

import {Link, useLocation} from 'react-router-dom'


let menusData =[
    {
        key:'/home',
        icon:<HomeOutlined/>,
        label:<Link to="/home">首页</Link>,
        authPath:'/home'
    },
    {
        key:'/users',
        icon:<UserOutlined/>,
        label:<Link to="/users">用户管理</Link>,
        authPath:'/home/user'
    },
    {
        key:'/roles',
        icon:<TeamOutlined />,
        label:<Link to="/roles">角色管理</Link>,
        authPath:'/home/role'
    },
    {
        key:'/shops',
        icon:<ShoppingCartOutlined />,
        label:<Link to="/shops">商铺管理</Link>,
        authPath:'/home/shop'
    },
    {
        key:'/products',
        icon:<ShoppingCartOutlined />,
        label:"商品管理",
        authPath:'/home/product',
        children:[
            {
                key:'/products/category',
                icon:<BarcodeOutlined />,
                label: <Link to="/products/category">分类管理</Link>,
                authPath:'/home/product/category',
            }, {
                key:'products/list',
                icon:<BarsOutlined />,
                label:<Link to="/products/list">商品列表</Link>,
                authPath:'/home/product/list',
            }

        ]
    },
    {
        key:'/finances',
        icon:<BarChartOutlined />,
        label:"财务统计",
        authPath:'/home/datav',
        children:[
            {
                key:'5-1',
                icon:<PayCircleOutlined />,
                label:"支出流水",
                authPath:'/home/datav/flowers'
            }, {
                key:'5-2',
                icon:<MoneyCollectOutlined />,
                label:<Link to="/finances/sale">销售金额</Link>,
                authPath:'/home/datav/sale'
            }

        ]
    }
]
const SideMenu = () => {
    let {pathname} = useLocation();
    //获取到本地存储中的用户权限菜单数据
    //保存权限菜单的状态变量
    let authMenus = []
    let userInfo = localStorage.userInfo
    if(userInfo){

        let {role:{menus}} = JSON.parse(userInfo)
        // console.log("menus",menus)
        //筛选数据并且保存权限菜单
        authMenus = menusData.filter(item=> menus.includes(item.authPath)).map(item=>{
            if(item.children){ //有孩子的菜单需要先处理孩子的菜单
                return {
                    key:item.key,
                    icon:item.icon,
                    label:item.label,
                    children:item.children.filter(child=> menus.includes(child.authPath)).map(ch=>{
                        return {
                            key:ch.key,
                            icon:ch.icon,
                            label:ch.label
                        }
                    })
                }
            }
            return { //没有孩子的菜单，只需要去掉authPath属性即可
                key:item.key,
                icon:item.icon,
                label:item.label
            }

        })
    }

    return (
        <div>
            <Menu
                mode="inline"
                defaultSelectedKeys={[pathname]}
                defaultOpenKeys={['/'+pathname.split('/')[1]]}
                style={{
                    height: '100%',
                    borderRight: 0,
                }}
                items={authMenus}
            />
        </div>
    );
};

export default SideMenu;