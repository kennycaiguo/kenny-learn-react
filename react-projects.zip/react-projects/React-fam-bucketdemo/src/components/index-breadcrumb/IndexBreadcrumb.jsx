import {Breadcrumb} from "antd";
// import React from "react";
import {useLocation} from "react-router-dom";
// import BreadcrumbItem from "antd/es/breadcrumb/BreadcrumbItem";

let breadcrumbsData = [
    // {path:"/",value:['首页']},
    {path:"/home",value:['首页']},
    {path:"/user",value:['首页','用户管理']},
    {path:"/roles",value:['首页','角色管理']},
    {path:"/products/category",value:['首页','商品管理','商品分类']},
    {path:"/products/list",value:['首页','商品管理','商品列表']},
    {path:"/products/update",value:['首页','商品管理','修改商品']},
    {path:"/finances/sale",value:['首页',"财务统计","销售金额"]}
]

const IndexBreadcrumb = () => {
    let {pathname} = useLocation()
    // console.log("pathname",pathname)
    let breadcrumbsItem = breadcrumbsData.find(item =>pathname.includes(item.path))?.value
    // console.log(breadcrumbsItem)
    //对上面的数据进行处理，返回一个类似于  {title:"Home"}的对象数组，然后在下面的items里面使用
    let breadcrumbsItemobj = breadcrumbsItem?.map(item=>{
        return {
            title:item
        }
    })
    console.log(breadcrumbsItemobj)
    return (
        <Breadcrumb
            style={{
                margin: '16px 0',
            }}
            items = {[
                ...breadcrumbsItemobj
            ]}

        >
            {/*{*/}
            {/*   breadcrumbsItem?.map((item,index) => (*/}
            {/*       <Breadcrumb.Item key={index}>{item}</Breadcrumb.Item>*/}
            {/*   ))*/}
            {/*}*/}

        </Breadcrumb>
    );
};

export default IndexBreadcrumb;
