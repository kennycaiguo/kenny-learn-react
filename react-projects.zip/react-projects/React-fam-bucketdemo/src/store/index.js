import {legacy_createStore,combineReducers,applyMiddleware} from "redux";
import {rolesReducer} from "./roles/reducers";
//引入redux-thunk中间件
import {thunk }from 'redux-thunk'
import {categoryReducer} from "./category/reducers";
import {usersReducers} from "./users/reducers";

//合并所有模块的reducer函数
let allReducer = combineReducers({
   roles:rolesReducer,
   category:categoryReducer,
   users:usersReducers
});

//应用中间件
let middleware = applyMiddleware(thunk);
let store = legacy_createStore(allReducer,middleware); 

export default store