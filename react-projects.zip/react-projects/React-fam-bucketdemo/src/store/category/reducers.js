import {SET_CATEGORY, SET_SUB_CATEGORY} from "./actionTypes";

export let categoryReducer = (state= [],action) =>{
    switch (action.type) {
        case SET_CATEGORY:
            return action.payload.map(item=>{
                return {
                    ...item,
                    children:[]
                }
            })
        //添加二级分类
        case SET_SUB_CATEGORY:
         //需要先保留一级分类的数据，然后添加二级分类的数据
         return state.map(item=>{
             if(item.id === action.payload.parentId){
                return {
                    ...item,
                    children:action.payload.children
                }
             }
             return item
         })
        default:
            return state
    }

}