import {getCategoryApi} from "../../api/category";
import {SET_CATEGORY, SET_SUB_CATEGORY} from "./actionTypes";

//设置action的方法
let setCategoryAction = (data) =>{
    return {
            type:SET_CATEGORY,
            payload:data
    }
}
//将组件里面的actioncs也封装成一个方法
export let setSubCategoryAction = (data) =>{
    return {
        type:SET_SUB_CATEGORY,
        payload:data
    }
}

export let getCategoryAsync = (params) =>{

    return async (dispatch)=>{
        //调用我们封装的发送请求获取数据的api，直接调用，需要使用传入的dispatch方法来保存数据
        // let res = await getCategoryApi()
        let res = await getCategoryApi(params)
        // console.log("分类数据",res)
        //保存数据到仓库
        dispatch(setCategoryAction(res))
    }
}