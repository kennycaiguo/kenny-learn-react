import {getUserApi} from "../../api/users";
import {SET_USERS} from "./actionTypes";


//封装方法来返回action对象
let setUserAction = (payload) =>{
    return {type:SET_USERS,payload}
}

export let getUsersAsync = () =>{
    return async (dispatch) =>{
        let res = await getUserApi()
        if(res){
            // console.log("用户数据",res)
            //触发reducer方法并且传递数据给他，让他保存数据到仓库
            dispatch(setUserAction(res)) //需要封装方法来分号action对象
        }

    }
}