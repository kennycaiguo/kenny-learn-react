import {SET_USERS} from "./actionTypes";

export let usersReducers = (state=[],{type,payload}) =>{
    switch (type) {
        case SET_USERS:
            return payload
        default:
            return state
    }
}