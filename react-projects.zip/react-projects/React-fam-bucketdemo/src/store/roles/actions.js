import {getRolesApi} from "../../api/roles";

export let getRolesAsync =  () =>{
    return async(dispath)=>{ //返回一个函数
        //调用api，发送异步请求
        let res = await getRolesApi() //我的接口返回的数据结构和老师的不一样，我的少一层data
        //保存数据
        if(res){
            // console.log(res)
            //调用仓库的reducer方法把新数据保存到仓库
            dispath({type:'SET_ROLES', payload:res})
        }
    }
}