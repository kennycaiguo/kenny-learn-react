export let rolesReducer = (state=[],action)=>{
    // console.log("action:",action)
    switch (action.type) {
        case "SET_ROLES":
            return action.payload
        default:
            return state
    }

}