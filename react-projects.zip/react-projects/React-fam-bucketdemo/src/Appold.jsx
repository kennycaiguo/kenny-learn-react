import  {Suspense,lazy} from 'react';
import {BrowserRouter,Route,Routes,Navigate} from "react-router-dom";
import LoginPage from "./pages/login/LoginPage";
import IndexPage from "./pages/index/IndexPage";
import HomePage from "./pages/index/home/HomePage";
import UsersPage from "./pages/index/users/UsersPage";
import RolesPage from "./pages/index/roles/RolesPage";
import ProductsCategory from "./pages/index/products/ProductsCategory";
import ProductsList from "./pages/index/products/ProductsList";
import ProductsUpdate from "./pages/index/products/ProductsUpdate";
import FinancesSale from "./pages/index/finances/FinancesSale";
import  ProductsUpdateDynamic from "./pages/index/products/ProductsUpdateDynamic"



let NotFound = lazy(()=>import("./pages/404/NotFound"));

const App = () => {
    return (
        <div>
            <Suspense fallback={<h1>加载中...</h1>}>
                <BrowserRouter>
                    <Routes>
                        <Route path="/" element ={<Navigate to="/home"/>}></Route>
                        <Route path="/" element={<IndexPage/>}>
                            <Route  path="home" element={<HomePage/>}></Route>
                            <Route  path="users" element={<UsersPage/>}></Route>
                            <Route  path="roles" element={<RolesPage/>}></Route>
                            <Route  path="products/category" element={<ProductsCategory/>}></Route>
                            <Route  path="products/list" element={<ProductsList/>}></Route>
                            {/*动态路由*/}
                            <Route  path="products/update/:id" element={<ProductsUpdateDynamic/>}></Route>
                            {/*state传参*/}
                            <Route  path="products/update" element={<ProductsUpdate/>}></Route>
                            {/*配置财务统计的销售金额路由*/}
                            <Route  path="finances/sale" element={<FinancesSale/>}></Route>
                        </Route>
                        <Route path="/login" element={<LoginPage/>}></Route>
                        <Route path='*' element={<NotFound/>}></Route>
                    </Routes>
                </BrowserRouter>
            </Suspense>

        </div>
    );
};

export default App;