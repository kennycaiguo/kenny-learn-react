import AddRoute from "./router/AddRoute.jsx";
import {BrowserRouter} from "react-router-dom";
import  {Suspense} from 'react';

const App = () => {
    return (
        <div>
            <Suspense fallback={<h1>加载中...</h1>}>
                <BrowserRouter>
                    <AddRoute/>
                </BrowserRouter>
            </Suspense>

        </div>
    );
};

export default App;