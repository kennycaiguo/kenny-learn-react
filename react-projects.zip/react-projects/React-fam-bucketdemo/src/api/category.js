import request from "../utils/request";

//获取指定的分类
export let getCategoryApi = (params)=>request.get("/category",{params})
//获取所有分类
export let getCascaderCategoryApi = ()=> request.get("/category")