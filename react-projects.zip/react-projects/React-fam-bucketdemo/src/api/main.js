//用户登录接口
import {getUserApi} from "./users.js";
import {getRolesApi} from "./roles.js";
let result ={}
//这个一个模拟登录接口，由于json-server不能做登录功能我们就在这里先获取所有用户然后根据表单的数据来找用户，找到了就是登录成功，否则失败
export let loginApi = async (values)=>{

       let users = await getUserApi()
       // console.log(users) 是一个promise对象
        let user = users.find(item=>item.account == values.account && item.password==values.password)
        if(user){
            // console.log("登录成功")
            // console.log("account",user.account)
            // console.log("role",user.role)
            let ret = await getRolesApi()
            // console.log(ret)
            let  res = ret.find(item=>item.id == user.role.id)
            // console.log(res.menus)
            user.role.menus = res.menus

            result = {"userInfo":{
                    "account":user.account,
                    "role": user.role
                },token:user.token}
            // console.log("result:",result)
        } else{
            console.log("用户名或者密码错误")
            result = null
        }
         return result
}