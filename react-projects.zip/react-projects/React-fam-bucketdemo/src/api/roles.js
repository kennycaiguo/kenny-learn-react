import request from "../utils/request";

export  let getRolesApi = ()=>request.get("/roles")