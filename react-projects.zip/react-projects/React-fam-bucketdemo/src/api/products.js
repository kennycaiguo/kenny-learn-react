import request from "../utils/request";

export let getProductsApi = ()=>request.get("/goods")
export let findProductByIdApi =(id)=>request.get(`/goods/${id}`)