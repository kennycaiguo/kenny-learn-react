import request from "../utils/request";

//获取使用用户列表
export let getUserApi = () => request.get("/users")
//删除用户
export let delUserApi = (id) =>{
    request.delete(`/users/${id}`).then(r => console.log(r))
    return id
}
//新增用户
export let addUserApi = (data)=>request.post("/users",data)
//修改用户信息
export let updateUserApi = (id,data) =>request.put(`/users/${id}`,data)


