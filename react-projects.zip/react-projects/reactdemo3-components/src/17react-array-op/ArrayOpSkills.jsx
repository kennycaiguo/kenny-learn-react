import React, {useState} from 'react';

const ArrayOpSkills = () => {
    let [students,setStudents] = useState([
        {
            id:1,
            name:'李连杰'
        },
        {
            id:2,
            name:'赵丽颖'
        },
        {
            id:3,
            name:'周迅'
        }
    ])

    let add = ()=>{
       setStudents([
           ...students,
           {
               id:students.length+1,
               name:'赵晓虎'
           }
       ])
    }
    let update = (id)=>{
        setStudents(students.map(item=>{
            if(item.id==id){
                return {
                    ...item,
                    name:'xiaoming'
                }
            }
            return item
        }))
    }
    let del = (id)=>{
        setStudents(students.filter(item=>item.id!=id))
    }
    return (
        <div>
            <h3>学生列表</h3>
            {students.map(item=>{
                return (<li key={item.id}>
                    {item.name}
                    <button onClick={()=>update(item.id)}>修改</button>
                    <button onClick={()=>del(item.id)}>删除</button>
                </li>)
            })}
            <button onClick={add}>新增</button>
        </div>
    );
};

export default ArrayOpSkills;
