import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
// import './index.css'
import FuncComponent from "./01-compoment-basic/FuncComponent";
import ClassComponent from "./01-compoment-basic/ClassComponent";

ReactDOM.createRoot(document.getElementById('root')).render(

    <App />
    // <FuncComponent/>
    // <ClassComponent/>
)
