import React, {Component} from 'react';

class SideMenu extends Component {
    state={
        menus:[
            {id:1,title:'首页'},
            {
                id:2,title:'商品管理',
                children:[
                    {
                        id:'2-1',title:'商品列表'
                    },
                    {
                        id:'2-2',title:'新增商品'
                    }

                ]
            },
            {
                id:3,title:'订单管理',

                children: [
                    {
                        id:'3-1',title:'订单列表'
                    },
                    {
                        id:'3-2',title:'新增订单'
                    }
                ]
            }
        ],
        openId:0
    }
    setOpenId=(openId)=>{
        if(openId == this.state.openId){
            this.setState({
                openId:0
            })
        } else {
            this.setState({
                openId
            })
        }

    }
    render() {
         let {menus,openId} = this.state
        return (
            <div>
                {
                    menus.map(item=>{
                        return (
                            <dl key={item.id}>
                                <dt  onClick={()=>{
                                   this.setOpenId(item.id)
                                }}>{item.title}</dt>
                                {
                                    //写法1
                                  //   item.children? item.children.map(child=>{
                                  //   return(
                                  //         <dd key={child.id}>{child.title}</dd>
                                  //    )
                                  //
                                  // }):null
                                    //写法2
                                   item.id===openId? item.children?.map(child=>{
                                        return(
                                            <dd key={child.id}>{child.title}</dd>
                                        )

                                    }):null
                                }


                            </dl>
                        )
                    })
                }
            </div>
        );
    }
}

export default SideMenu;