import React from 'react';

const FuncComponent = () => {
    let person = {
        name:'Linda Lee',
        gender:'female',
        age:20,
        email:'Linda12345hello@gmail.com'
    }
    return (
        <div>
            <h2>个人资料</h2>
            <p>姓名：{person.name}</p>
            <p>性别：{person.gender}</p>
            <p>年龄：{person.age}</p>
            <p>email：{person.email}</p>
            <span>end</span>
        </div>
    );
};

export default FuncComponent;