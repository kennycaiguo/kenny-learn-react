import React, {Component} from 'react';

class ClassComponent extends Component {
    render() {
        return (
            <div>
                <h1>这是类组件里面的内容</h1>
            </div>
        );
    }
}

export default ClassComponent;