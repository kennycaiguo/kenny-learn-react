// eslint-disable-next-line no-unused-vars
import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'
import FuncComponent from "./01-compoment-basic/FuncComponent";
import ClassComponent from "./01-compoment-basic/ClassComponent";
import ClassEvent from "./02-class-component-events/ClassEvent";
import ClassState from "./03class-component-state/ClassState";
import ClassComputed from "./04class-computed-property/ClassComputed"
import ClassLifeCycle from "./05class-comp-life-cycle/ClassLifeCycle";
// import SideMenu from "./side-menu/SideMenu";
import SideMenu2 from "./side-menu-v2/SideMenu2";
import ComponentStyle from "./06component-style/ComponentStyle";
import FunctionState from "./07readct-hook-useState/FunctionState";
import FunctionLifeCycle from "./08react-Hook-useEffect/FunctionLifeCycle";
import FunctionComputed from "./09react-Hook-useMemo/FunctionComputed";
import FunctionComputed2 from "./09react-Hook-useMemo/FunctionComputed2";
import FunctionRef from "./10react-Hook-useRef/FunctionRef";
import TodoList from "./exercise-todoList/TodoList";
import FunctionProps from "./11react-props/FunctionProps";
import FatherProp from "./11react-props/FatherProp";
import FatherEvent from "./12comp-communication/FatherEvent";
import GrandFather from "./13multilayer-comp-communication/GrandFather";
import FatherMemo from "./14func-component-optimize/FatherMemo";
import NameForm from "./NameForm";
import FunctionFormUnControlled from "./15react-form/FunctionFormUnControlled";
import FunctionFormControlled from "./15react-form/FunctionFormControlled";
import ImageRender from "./16react-image-rendering/ImageRender";
import ArrayOpSkills from "./17react-array-op/ArrayOpSkills";
import ManageProduct from "./exercise-product-list/ManageProduct";


function App() {
   let props={
       name :'jack' ,
       age:35,
       gender:'male' ,
       money:9000000
   }
  return (
    <>
      {/*<h1>React demo3</h1>*/}
      {/*<FuncComponent/>*/}
      {/*<ClassComponent/>*/}
      {/*<ClassEvent/>*/}
      {/*  <ClassState></ClassState>*/}
      {/* <ClassComputed></ClassComputed>*/}
      {/*  <ClassLifeCycle></ClassLifeCycle>*/}
      {/*  <SideMenu></SideMenu>*/}
      {/*  <SideMenu2/>*/}
      {/* <ComponentStyle></ComponentStyle>*/}
      {/*  <FunctionState></FunctionState>*/}
      {/*  <FunctionLifeCycle></FunctionLifeCycle>*/}
      {/*  <FunctionComputed></FunctionComputed>*/}
      {/*  <FunctionComputed2></FunctionComputed2>*/}
      {/*  <FunctionRef/>*/}
      {/*<TodoList/>*/}
      {/*  <FunctionProps name = 'jack' age={30} gender='male' money={100000} />*/}
      {/*  <FunctionProps {...props} />*/}
      {/*  <FatherProp/>*/}
      {/*  <FatherEvent/>*/}
      {/*  <GrandFather/>*/}
      {/*  <FatherMemo/>*/}
      {/*  <NameForm/>*/}
      {/* <FunctionFormUnControlled/>*/}
      {/*  <FunctionFormControlled/>*/}
      {/*  <ImageRender/>*/}
      {/*  <ArrayOpSkills/>*/}
        <ManageProduct/>
    </>
  )
}

export default App


