import React, {useState} from 'react';
import Father from "./Father";
import Context from './context'

const GrandFather = () => {
    let [count ,setCount] = useState(0)
    return (
        <div style={{border:'1px solid deeppink'}}>
            <h3>GrandFather</h3>
            <Context.Provider value={{count,setCount}}>
                <Father/>
            </Context.Provider>
        </div>
    );
};

export default GrandFather;