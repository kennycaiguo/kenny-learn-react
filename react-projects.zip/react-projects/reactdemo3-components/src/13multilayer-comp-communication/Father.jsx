import React from 'react';
import Son from "./Son";


const Father = () => {
    return (
        <div style={{border:'1px dashed skyblue'}}>
            <h4>father</h4>
            <Son/>
        </div>
    );
};

export default Father;