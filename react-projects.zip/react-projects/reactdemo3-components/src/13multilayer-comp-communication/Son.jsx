import React, {useContext} from 'react';
import Context from "./context";

const Son = () => {
    let {count,setCount} = useContext(Context)
    return (
        <div style={{background:"#cccccc",color:'deeppink'}}>
            <h5>Son</h5>
            <button onClick={()=>setCount(--count)}>-</button>
              <span >{count}</span>
            <button onClick={()=>setCount(++count)}>+</button>
        </div>
    );
};

export default Son;