import React, {Component} from 'react';

class ClassComputed extends Component {
    state={
        num1:10,
        num2:20
    }
    get sum(){
        return this.state.num1 + this.state.num2
    }

    render() {
        return (
            <div>
                <h3>总数是：{this.sum}</h3>
            </div>
        );
    }
}

export default ClassComputed;