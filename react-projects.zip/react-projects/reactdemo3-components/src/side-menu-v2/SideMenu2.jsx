import React, {Component,PureComponent} from 'react';

class SideMenu2 extends PureComponent {
    state={
        menus:[
            {id:1,title:'首页'},
            {
                id:2,title:'商品管理',
                open:true,
                children:[
                    {
                        id:'2-1',title:'商品列表'
                    },
                    {
                        id:'2-2',title:'新增商品'
                    }

                ]
            },
            {
                id:3,title:'订单管理',
                open:true,
                children: [
                    {
                        id:'3-1',title:'订单列表'
                    },
                    {
                        id:'3-2',title:'新增订单'
                    }
                ]
            }
        ],

    }
    // setOpen = (id)=>{
    //     this.state.menus.forEach(item=>{
    //         if(item.id ===id){
    //             item.open = !item.open
    //         }
    //
    //     })
    //     this.setState({
    //         ...this.state
    //     })
    // }
    setOpen = (id)=>{

        this.setState({
           menus:this.state.menus.map(item=>{
               if(item.id ===id){
                  return {
                      ...item,//保留对象旧属性
                      open:!item.open
                  }
               }
               return  item
           })
        })
    }
    render() {
        let {menus} = this.state
        return (
            <div>
                {
                    menus.map(item=>{
                        return (
                            <dl key={item.id}>
                                <dt onClick={()=>this.setOpen(item.id)}>{item.title}</dt>
                                {
                                 item.open? item.children?.map(child=>{
                                        return(
                                            <dd key={child.id}>{child.title}</dd>
                                        )

                                    }):null
                                }


                            </dl>
                        )
                    })
                }
            </div>
        );
    }
}

export default SideMenu2;