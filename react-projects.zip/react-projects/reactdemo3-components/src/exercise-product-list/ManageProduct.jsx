import React, {useMemo, useState} from 'react';
let initProducts=[
    {id:1,name:'短袖T恤',price:50,count:10,sale:true},
    {id:2,name:'牛仔裤',price:100,count:20,sale:true},
    {id:3,name:'羽绒服',price:300,count:0,sale:false},
    {id:4,name:'运动服',price:300,count:12,sale:false},
]
let initFilters=[
    {id:1,title:'全部'},
    {id:2,title:'在售中'},
    {id:3,title:'已下架'},
    {id:4,title:'已售罄'},
]
const ManageProduct = () => {
    let [products,setProducts] = useState(initProducts)
    let [filters,setFilters] = useState(initFilters)
    //默认选中项
    let [filterId,setFilterId] = useState(1)
    //获取符合条件的数据的计算属性
    let filterProducts = useMemo(()=>{
        switch (filterId) {
            case 2:
                return products.filter(item=>item.sale)
                break
            case 3:
                return products.filter(item=>!item.sale && item.count !=0)
                break
            case 4:
                return products.filter(item=>{
                    return item.count==0
                })
                break
            default:
                return products
                break
        }
    },[products,filterId])
    //计算库存的计算属性
    // let totalCount = useMemo(()=>{ //这个已经没有用了
    //     return products.reduce((sum,item)=>sum + item.count ,0)
    // },[products])
    let totalCount = useMemo(()=>{
        return filterProducts.reduce((sum,item)=>sum + item.count ,0)
    },[filterProducts])

    //计算总价的计算属性
    // let totalPrice = useMemo(()=>{//这个已经没有用了
    //     return products.reduce((sum,item)=>sum + item.count * item.price ,0)
    // },[products])
    let totalPrice = useMemo(()=>{
        return filterProducts.reduce((sum,item)=>sum + item.count * item.price ,0)
    },[filterProducts])

    let status = (item)=>{
        //写法1
         // if(item.count >0 ){
         //     if(item.sale){
         //         return "在售中"
         //     }
         //     return "已下架"
         // }  else{
         //     return '已售罄'
         // }
        //写法3
        // if(item.count===0){
        //     return  <span style={{color:'orange'}}>已售罄</span>
        // } else {
        //     if(item.sale){
        //         return  <span style={{color:'blue'}}>在售中</span>
        //     }
        //     return  <span style={{color:'red'}}>已下架</span>
        // }
        //写法2
        if(item.count===0){
            return  <span style={{color:'red'}}>已售罄</span>
        }
        if(item.sale){
            return  <span style={{color:'blue'}}>在售中</span>
        }
        return  <span style={{color:'orange'}}>已下架</span>
    }
    //下架函数
    let soldOut = (id) =>{
       setProducts(products.map(item=>{
           if(item.id==id){
               return {
                   ...item,
                   sale:false
               }
           }
           return item
       }))
    }
    //上架函数
    let putOnSale = (it)=>{
        //库存为0不能上架
        if(it.count==0){
            alert('库存为0，不能上架，请增加库存')
            return
        }
        setProducts(products.map(item=>{
            if(item.id==it.id){
                return {...item, sale:true}
            }
            return item
        }))
    }

    //减少库存
    let decrement=(it)=>{
        if(it.count==0){
            // alert('库存为0，不能减少，请增加库存')
            return
        }
        setProducts(products.map(item=>{
            if(item.id==it.id){
                return {
                    ...item,
                    count:item.count-1
                }
            }
            return item
        }))
    }
    //增加库存
    let increment=(id)=>{
        setProducts(products.map(item=>{
            if(item.id==id){
                return {
                    ...item,
                    count:item.count+1
                }
            }
            return item
        }))
    }
    //删除货品
    let remove  = (id)=>{
        setProducts(products.filter(item=>item.id != id))
    }
    return (
        <div>
            <h3>ManageProduct</h3>
            <div>
                {filters.map(item=><span style={{backgroundColor:item.id==filterId?'#bbb':'transparent'}}
                 key={item.id} onClick={()=>setFilterId(item.id)}>
                    {item.title} </span>)}
            </div>
            <table>
                <thead>
                <tr>
                    <th>编号</th>
                    <th>商品名称</th>
                    <th>单价</th>
                    <th>库存</th>
                    <th>状态</th>
                    <th>操作</th>
                </tr>
                </thead>
                <tbody>
                {
                    filterProducts.map(item=>{
                    return (
                        <tr key={item.id}>
                            <td>{item.id}</td>
                            <td>{item.name}</td>
                            <td>{item.price}</td>
                            <td>
                                <button onClick={()=>decrement(item)}>-</button>
                                {item.count}
                                <button onClick={()=>increment(item.id)}>+</button></td>
                            <td>{status(item)}</td>
                            <td>
                                {item.sale? (<button onClick={()=>soldOut(item.id)}>下架</button>)
                                    :(<button onClick={()=>putOnSale(item)}>上架</button> )}
                                <button onClick={()=>remove(item.id)}>删除</button>
                            </td>
                        </tr>
                    )
                })}
                </tbody>
            </table>
            <div>
                <p>当前库存{totalCount}件，共计{totalPrice}元</p>
            </div>
        </div>
    );
};

export default ManageProduct;
