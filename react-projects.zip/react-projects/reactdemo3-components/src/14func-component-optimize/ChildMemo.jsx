import React ,{memo} from 'react';

const ChildMemo = (props) => {

    console.log('================子组件')
    return (
        <div>
            <h3>child memo</h3>
            <span>Message:{props.sayHello()}</span>
        </div>
    );
};

export default memo(ChildMemo);