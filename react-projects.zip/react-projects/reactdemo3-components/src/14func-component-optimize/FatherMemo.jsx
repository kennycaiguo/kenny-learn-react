import React, {useCallback, useState} from 'react';
import ChildMemo from "./ChildMemo";

const FatherMemo = () => {
    console.log('父组件')
    let [count,setCount] = useState(0)
    let sayHello = ()=>{
        let msg = 'hello from dad';
        console.log(msg)
        return msg
    }
    var sayHelloCb = useCallback(sayHello,[]);
    return (
        <div>
            <h3>{count}</h3>
            <button onClick={()=>setCount(++count)}>add</button>
            <ChildMemo sayHello={sayHelloCb} />
        </div>
    );
};

export default FatherMemo;