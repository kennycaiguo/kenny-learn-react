import React, {Component} from 'react';
import './style.css'
import style from './style.module.css'
class ComponentStyle extends Component {
    render() {
        return (
            <div>
               {/*<span style={{color:'deeppink',border:'1px dashed green'}}>内联样式</span><br/>*/}
                <span>外部全局样式</span><br/>
                <span className={style.content}>外部局部样式</span>
            </div>
        );
    }
}

export default ComponentStyle;