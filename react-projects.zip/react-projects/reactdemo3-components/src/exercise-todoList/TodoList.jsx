import React, {useMemo, useRef, useState} from 'react';
import styles from './todo.module.css'
let initTodos = [
    {id: 1, value: '学习html', done: false},
    {id: 2, value: '学习css', done: true},
    {id: 3, value: '学习js', done: false},
]
let initResult = [
    {id: 1, value: '全部'},
    {id: 2, value: '已完成'},
    {id: 3, value: '未完成'},
]

const TodoList = () => {
    let [todos,setTodos] = useState(initTodos)
    let [resultList,setResultList] = useState(initResult)
    let [selectedId,setSelectedId] = useState(1)
    let inputRef = useRef(null)
    //计算属性
    var filteredTodos = useMemo(()=>{
        switch (selectedId) {
            case 2:
                return todos.filter(item=> item.done)
                break
            case 3:
                return todos.filter(item=> !item.done)
                break
            default:
                return todos
                break
        }
    },[selectedId,todos]);

    let finshedTotal = useMemo(()=>{
        return todos.filter(item=>item.done).length
    },[todos])


    let addTodo = ()=>{
       let addValue = inputRef.current.value;
        // todos.push({id:todos.length+1,value:addValue,done:false})
        // console.log(todos)
       setTodos([
           ...todos,
           {
               id:todos.length+1,
               value:addValue,
               done:false}
        ]);
        inputRef.current.value=''
    }
    //点击事件处理函数
   const doneChange = (id)=>{
     setTodos(todos.map(item=>{
         if(item.id === id){
             return {
                 ...item,
                 done:!item.done
             }
         }
         return item
      }))
       // console.log(newTodos)
      // setTodos(newTodos)
   }

    return (
        <div>
            <h3>TodoList</h3>
            <div>
                <input type="text" ref={inputRef}/>
                <button onClick={addTodo}>新增</button>
            </div>
            <ul>
                {
                    // todos.map(item=>
                    //     <li onClick={()=>doneChange(item.id)}
                    //         className={item.done?styles.done:''}  key={item.id} >
                    //         {item.value}
                    //     </li>)
                    filteredTodos.map(item=>
                        <li onClick={()=>doneChange(item.id)}
                            className={item.done?styles.done:''}  key={item.id} >
                            {item.value}
                        </li>)
                }
            </ul>
            <div>
                {resultList.map(item=>{
                    if(item.id === selectedId){
                        return <span key={item.id}>{item.value}</span>
                    }
                    return <a href="#" key={item.id} onClick={(e)=>{
                        e.preventDefault()
                        setSelectedId(item.id)}
                    }>{item.value}</a>
                })}
                <span>  进度：{finshedTotal}/{todos.length}</span>
            </div>
        </div>
    );
};

export default TodoList;