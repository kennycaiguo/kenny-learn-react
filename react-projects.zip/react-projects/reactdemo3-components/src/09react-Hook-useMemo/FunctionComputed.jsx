import React, {useMemo, useState} from 'react';

const FunctionComputed = () => {
    let [count,setCount] = useState(1)
    var result = useMemo(()=>{
        console.log('useMemo')
        return count+10/2+count
    },[count]);


    return (
        <div>
            <h3>{result}</h3>
            <h3>{result}</h3>
            <h3>{result}</h3>

        </div>
    );
};

export default FunctionComputed;