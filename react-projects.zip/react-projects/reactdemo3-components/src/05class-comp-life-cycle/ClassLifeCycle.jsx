import React, {Component,PureComponent} from 'react';

class ClassLifeCycle extends PureComponent {
    // constructor() { //这是一个常用的生命周期函数，但是react帮我们简化了，我们不需要经常写
    //     super();
    //     console.log('constructor()')
    // state = {
    //     num:1
    // }
    // }

    state = {
        num:1
    }
    componentDidMount() {
        console.log('组件挂载完成，可以发送网络请求')
    }

    componentDidUpdate(prevProps, prevState, snapshot) {
        console.log('componentDidUpdate called ')
        console.log(prevProps)
        console.log(prevState)
    }
    componentWillUnmount() {
        console.log('即将卸载组件')
    }
    // shouldComponentUpdate(nextProps, nextState, nextContext) { //继承自PureComponent的组件不需要写这个函数
    //     console.log('inside shouldComponentUpdate')
    //     // console.log(nextProps)
    //     // console.log(nextState)
    //     // console.log(nextContext)
    //     if(nextState.num === this.state.num){
    //         return false
    //     }
    //
    //     return true
    // }

    render() {
        console.log('render()')
        return (
            <div>
                <h4>ClassLifeCycle</h4>
                <h5>{this.state.num}</h5>
                <button onClick={()=>{
                    this.setState({
                        num:this.state.num+1
                        // num:1
                    })
                }}>改变数字</button>
            </div>
        );
    }
}

export default ClassLifeCycle;


