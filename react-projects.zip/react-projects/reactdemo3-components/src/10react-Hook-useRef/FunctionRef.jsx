import React, {useRef, useState} from 'react';

const FunctionRef = () => {
    let [count,setCount] = useState(0)
    let inputRef = useRef(null)
    return (
        <div>
            <h3>count:{count}</h3>
            {/*<input type="text" onChange={(e)=>{*/}
            {/*    setCount(e.target.value)*/}
            {/*}}/>*/}
            <input type="text" ref={inputRef} onBlur={(e)=>{
                setCount(Number(inputRef.current.value));
                inputRef.current.value = '';
            }}/>
        </div>
    );
};

export default FunctionRef;