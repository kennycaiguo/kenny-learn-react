import React, {Component} from 'react';

class ClassState extends Component {
    state = {
        name:'Jessie',
        age:20
    }
    increment= () =>{
        this.setState({
            age:this.state.age+1
        },()=>{
            console.log(this.state.age)
        })
        this.setState({
            name:'Jade'
        })
    }

    decrement=()=>{
        this.setState({
            age:this.state.age-1
        })
    }
    render() {
        let {name,age} = this.state
        return (
            <div>
               <h3>姓名:{name}</h3>
               <h3>年龄:{age}</h3>
                <button onClick={()=>{
                    this.setState({
                     name:'Jennifer'
                  })
                }}>修改姓名</button>
                <button onClick={this.increment}>增加年龄</button>
                <button onClick={this.decrement}>减小年龄</button>
            </div>
        );
    }
}

export default ClassState;