import React, {useEffect, useState} from 'react';

const FunctionLifeCycle = () => {
  let [count,setCount] = useState(1)
  let [name,setName] = useState('Mary')
  // useEffect(()=>{ //第一种用法
  //     console.log('useEffect')
  // })
  //   useEffect(()=>{ //第二种用法
  //     console.log('useEffect')
  // },[])
  //   useEffect(()=>{ //第三种用法
  //     console.log('useEffect')
  // },[count])
    useEffect(()=>{ //第四种用法
      console.log('useEffect')
      return ()=>{
          console.log('useEffect clean up')
      }
    })

    return (
        <div>
            <h3>{count}</h3>
            <h3>{name}</h3>
            <button onClick={()=>setCount(++count)}>count++</button>
            <button onClick={()=>setName('Jenifer')}>set name</button>
        </div>
    );
};

export default FunctionLifeCycle;