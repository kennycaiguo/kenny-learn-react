import React from 'react';
import img1 from './images/img1.jpg'
const ImageRender = () => {
    // console.log(img1)
    return (
        <div>
            <h3>ImageRender</h3>
            {/*<img src={img1} alt="图片"/>*/}
            <img src={new URL('./images/img1.jpg',import.meta.url).href} alt="图片"/>
        </div>
    );
};

export default ImageRender;
