import React, {useState} from 'react';
import ChildProp from "./ChildProp";


const FatherProp = () => {
    let [gender,setGender] = useState('男')
    const getChildData = (childData)=>{
        console.log('childData',childData)
    }
    return (
        <div>
            <h2>FatherProp</h2>
            <ChildProp name='Jack' age={30} getChildData={getChildData}/>
        </div>
    );
};

export default FatherProp;