import React from 'react';

const FunctionProps = (props) => {
    return (
        <div>
            <h4>name : {props.name}</h4>
            <h4>age: {props.age}</h4>
            <h4>gender:{props.gender}</h4>
            <h4>money:{props.money}</h4>
        </div>
    );
};

export default FunctionProps;