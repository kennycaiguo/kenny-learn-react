import React from 'react';
import pt from 'prop-types'
const ChildProp = (props) => {
    let {name,age,gender,getChildData} = props
    // let passToDad = ()=>{
    //     getChildData({
    //         name:'Son',
    //         age:20,
    //         gender:'male'
    //     })
    // }
     return (
        <div>
           <h3>ChildProp</h3>
            <p>name:{name}</p>
            <p>age:{age}</p>
            <p>gender:{gender}</p>
            <button onClick={()=> getChildData({
                name:'Son',
                age:20,
                gender:'male'
            })}>传递数据给父亲</button>

        </div>
    );
};
ChildProp.defaultProps={
    gender:'女'
}
ChildProp.propTypes = {
    name:pt.string,
    age:pt.number,
    gender:pt.string,


}
export default ChildProp;