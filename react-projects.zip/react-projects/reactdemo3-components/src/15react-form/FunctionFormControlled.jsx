import React, {useState} from 'react';

function setMyItem(e, setLikes, likes,myItem) {
    if (e.target.checked) {
        setLikes([
            ...likes,
            myItem
        ])
    } else {
        setLikes(likes.filter(item => item !== myItem))
    }
}

const FunctionFormControlled = () => {
    let [msg,setMsg] = useState('hello')
    let [gender,setGender] = useState('女')
    let [isChecked,setIsChecked] = useState(true)
    let [likes,setLikes] = useState([])
    let [addr,setAddr] = useState('云南')
    let handleChange=(e)=>{
        console.log(e.target)
        setMsg(e.target.value)

    }
    return (
        <div>
            <h3>受控组件：受react控制</h3>
            <input type="text" value={msg} onChange={(e)=>{
                console.log(e.target.value)
                setMsg(e.target.value)
            }} />
            <p>性别：{gender}</p>
            <input type="radio" checked={gender==='男'} onChange={(e)=>{
                setGender('男')
            }}/>男
            <input type="radio" checked={gender==='女'} onChange={(e)=>{
                setGender('女')
            }}/>女
            <ul>
                <h4>兴趣爱好</h4>
                {likes.map((item,index)=>{
                    return <li key={index}>{item}</li>
                })}
            </ul>
            <input type="checkbox" checked={likes.includes('泡妞')} onChange={(e)=>{
                setMyItem(e, setLikes, likes,'泡妞');
            }} />泡妞
            <input type="checkbox" checked={likes.includes('逛街')} onChange={(e)=>{
                 setMyItem(e, setLikes, likes,'逛街')
            }} />逛街
            <input type="checkbox" checked={likes.includes('上管子')} onChange={(e)=>{
                setMyItem(e, setLikes, likes,'上管子')
            }} />上管子
             <p>所在省份：{addr}</p>
            <select value={addr} onChange={(e)=>{
                setAddr(e.target.value)
            }}>
                <option value="四川">四川</option>
                <option value="广东">广东</option>
                <option value="云南">云南</option>
                <option value="贵州">贵州</option>
            </select>
        </div>
    );
};

export default FunctionFormControlled;
