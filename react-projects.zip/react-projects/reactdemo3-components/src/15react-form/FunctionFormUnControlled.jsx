import React, {useState} from 'react';

const FunctionFormUnControlled = () => {
    let [msg,setMsg] = useState('hello')
    let [isChecked,setIsChecked] = useState(true)
    return (
        <div>
            <h3>非受控组件</h3>

            <p>{msg}</p>
            <input type="text" defaultValue={msg}/>
            <button onClick={()=>setMsg('你好')}>change</button><br/>
            <input type="radio" name='gender' defaultChecked={isChecked} />男
            <input type="radio" name='gender' />女
            <select defaultValue="cpp">
                <option value="java">java</option>
                <option value="cpp">cpp</option>
                <option value="python">python</option>
            </select>
        </div>
    );
};

export default FunctionFormUnControlled;
