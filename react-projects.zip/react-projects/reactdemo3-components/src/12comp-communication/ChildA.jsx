import React from 'react';
import events from './events'

const ChildA = () => {
    return (
        <div>
           <button onClick={
               ()=>  events.emit('getData',{from:'ChildA',msg:'Hello ChildB',value:1000})
           }>传递数据</button>
        </div>
    );
};

export default ChildA;