import React from 'react';
import ChildA from "./ChildA";
import ChildB from "./ChildB";

const FatherEvent = () => {
    return (
        <div>
            <h4>Father</h4>
            <ChildA/>
            <ChildB/>
        </div>
    );
};

export default FatherEvent;