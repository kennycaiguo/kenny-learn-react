import React, {useEffect} from 'react';
import events from './events'

const ChildB = () => {
    useEffect(()=>{
        events.addListener('getData',(data)=>{
            console.log("组件A数据：",data);
        })
    },[])
    return (
        <div>
           childb
        </div>
    );
};

export default ChildB;