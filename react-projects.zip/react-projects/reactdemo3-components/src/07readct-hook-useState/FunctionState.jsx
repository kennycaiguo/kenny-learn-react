// eslint-disable-next-line no-unused-vars
import React, {useState} from 'react';

const FunctionState = () => {
    let [count,setCount] = useState(0);
    let setTimesCount=(times)=>{ //自定义方法可以在事件处理箭头函数里面调用
        setCount(count*times)
    }
    return (
        <div>

            <h3>当前计数：{count}</h3>
            <button onClick={()=>setCount(++count)}>+</button><button onClick={()=>setCount(--count)}>-</button>
            <button onClick={()=>setTimesCount(3)}>3times</button><button onClick={()=>setTimesCount(0.25)}>0.25times</button>
        </div>
    );
};

export default FunctionState;

