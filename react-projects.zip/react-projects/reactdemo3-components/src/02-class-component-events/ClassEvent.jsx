import React, {Component} from 'react';
// function doClick() {
//     return () => {
//         window.alert('hello from react')
//     };
// }


class ClassEvent extends Component {
    name = 'Jessica jade'
    doClick(){
        return () => {
                    window.alert('hello from react')
        };
    }
    doClick2=(name)=>{
        console.log(name + 'hello from react again')
    }

    handleClick(name){ //如果在按钮的点击事件里面调用时没有传递参数，系统会自动传递一个event对象给这个形参
        console.log(name);
    }
    render() {
        // let doClick = function () {
        //     return () => {
        //         window.alert('hello from react')
        //     };
        // }
        return (
            <div>
                <button onClick={this.doClick2}>按钮</button>
                <button onClick={()=> this.handleClick(this.name)}>按钮2</button>
                <button onClick={event => console.log(event)}>按钮3</button>
                <button onClick={this.handleClick}>按钮4</button>
            </div>
        );
    }
}

export default ClassEvent;