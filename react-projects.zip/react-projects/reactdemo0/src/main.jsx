import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
// import './index.css'
let pc = {
    name:'dell laptop 1234',
    memory:'32G',
    disk:'500G',
    price :2500
}
let mydiv = (
    <div>
        <h1>Computer info</h1>
        <p>Brand Name: {pc.name}</p>
        <p>Memory: {pc.memory}</p>
        <p>Disk Space: {pc.disk}</p>
        <p>Selling price(us-dollars): {pc.price}</p>
        <p>Comment:Price is {pc.price>2500?'Dear':'Cheap'}</p>
    </div>
)

ReactDOM.createRoot(document.getElementById('root')).render(
    // <App />,
    mydiv
)
