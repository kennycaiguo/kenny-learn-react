import { useState } from 'react'
// import reactLogo from './assets/react.svg'
// import viteLogo from '/vite.svg'
// import './App.css'

let books = [
    'Java web开发1000例',
    'C++从入门到精通',
    'Python爬虫实战',
    'Nodejs开发实战'
]
function App() {
  // const [count, setCount] = useState(0)

  return (
    <>

      <h1>React demo2</h1>
      <div className="card">
         <ul>
             {books.map(item=>{
                  return <li key={item}>{item}</li>
             })}
         </ul>
      </div>

    </>
  )
}

export default App
