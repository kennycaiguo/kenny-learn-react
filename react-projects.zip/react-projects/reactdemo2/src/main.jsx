import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
// import './index.css'


let age =19
function sayHello(){
        return 'Hello World of React!!!'
}
function getAgeSate() {//注意：这里不要传参，否则会得到错误的结果
   let age_span
   if(age >=18){
        return <span>是成年人</span>
   }
   return <span>尚未成年</span>

}
let Jessie = (
    <div>
        <h2>个人资料</h2>
        <p>姓名：Jessie</p>
        <p>性别：female</p>
        <p>年龄：{age}</p>
        <p>email：Jessie123@hotmail.com</p>
        {/*<p>{age>=18?'已经成年':'尚未成年'}</p>*/}
        {/*<p>{age>=18?<span>已经成年</span>:<span>尚未成年</span>}</p>*/}
        <p>{getAgeSate()}</p>
        <p>{sayHello()}</p>
        <label htmlFor="username" className='username'>用户名：</label>
            <input id='username' type="text"/>
    </div>
)

ReactDOM.createRoot(document.getElementById('root')).render(
      <App />
    // Jessie
)
